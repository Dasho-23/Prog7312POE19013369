﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace _19013369Task1
{
    class CallNumberTF
    {
      //declared list of string for each level of data
       public List<string> lvlOne = new List<string>();
       public List<string> lvlTwo = new List<string>();
       public List<string> lvlThree = new List<string>();
        
        public CallNumberTF()
        {

        }
        //Loads and sorts the data in to string lists
        public void ReadTextFiLe()
        {
            //declares a variable with file path

            string  path = @"C:\Users\Dishani\Documents\PROG7312\Prog7312_Task2_19013369_DishaniOdayar_G1\CallingNumbersLvl.txt";
            
            //declares string list
            List<string> lines = new List<string>();

            //reads all data from textfile in to list
            lines = File.ReadAllLines(path).ToList();
          
           

            //checks every line of data in list and determines whether its level one, two or three
            foreach (String line in lines)
            {
                //if the line of data contains * then the line is stored in the level one list
                if (line.Contains("*") == true)
                {
                
                    lvlOne.Add(line);


                }
                //if the line of data contains ! then the line is stored in the level two list
                else if (line.Contains("!"))
                {

                   
                    lvlTwo.Add(line);
                  
                }
                // the line is stored in the level three list
                else
                {
                  
                    lvlThree.Add(line);
                    
                }


         

            }
           
        }


    
    }

}
