﻿
namespace _19013369Task1
{
    partial class FindingCN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FindingCN));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCn = new System.Windows.Forms.Label();
            this.btnOptOne = new System.Windows.Forms.Button();
            this.btnOptTwo = new System.Windows.Forms.Button();
            this.btnOptThree = new System.Windows.Forms.Button();
            this.btnOptFour = new System.Windows.Forms.Button();
            this.btnGone = new System.Windows.Forms.Button();
            this.btnValid = new System.Windows.Forms.Button();
            this.lblLevelOne = new System.Windows.Forms.Label();
            this.pbLvlOne = new System.Windows.Forms.PictureBox();
            this.lbllevelTwo = new System.Windows.Forms.Label();
            this.pbLvlTwo = new System.Windows.Forms.PictureBox();
            this.lblJack = new System.Windows.Forms.Label();
            this.pbLvlThree = new System.Windows.Forms.PictureBox();
            this.lblLevels = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbLvlOne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLvlTwo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLvlThree)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(223, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Finding call numbers";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(97, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(544, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Match the correct call number with the description displayed below:";
            // 
            // lblCn
            // 
            this.lblCn.AutoSize = true;
            this.lblCn.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCn.Location = new System.Drawing.Point(43, 171);
            this.lblCn.Name = "lblCn";
            this.lblCn.Size = new System.Drawing.Size(110, 37);
            this.lblCn.TabIndex = 2;
            this.lblCn.Text = "label3";
            // 
            // btnOptOne
            // 
            this.btnOptOne.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOptOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnOptOne.Location = new System.Drawing.Point(23, 231);
            this.btnOptOne.Name = "btnOptOne";
            this.btnOptOne.Size = new System.Drawing.Size(342, 34);
            this.btnOptOne.TabIndex = 3;
            this.btnOptOne.Text = "button1";
            this.btnOptOne.UseVisualStyleBackColor = true;
            this.btnOptOne.Click += new System.EventHandler(this.btnOptOne_Click);
            // 
            // btnOptTwo
            // 
            this.btnOptTwo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOptTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnOptTwo.Location = new System.Drawing.Point(23, 282);
            this.btnOptTwo.Name = "btnOptTwo";
            this.btnOptTwo.Size = new System.Drawing.Size(342, 34);
            this.btnOptTwo.TabIndex = 4;
            this.btnOptTwo.Text = "button2";
            this.btnOptTwo.UseVisualStyleBackColor = true;
            this.btnOptTwo.Click += new System.EventHandler(this.btnOptTwo_Click);
            // 
            // btnOptThree
            // 
            this.btnOptThree.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOptThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnOptThree.Location = new System.Drawing.Point(420, 228);
            this.btnOptThree.Name = "btnOptThree";
            this.btnOptThree.Size = new System.Drawing.Size(342, 34);
            this.btnOptThree.TabIndex = 5;
            this.btnOptThree.Text = "button3";
            this.btnOptThree.UseVisualStyleBackColor = true;
            this.btnOptThree.Click += new System.EventHandler(this.btnOptThree_Click);
            // 
            // btnOptFour
            // 
            this.btnOptFour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOptFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnOptFour.Location = new System.Drawing.Point(420, 282);
            this.btnOptFour.Name = "btnOptFour";
            this.btnOptFour.Size = new System.Drawing.Size(342, 34);
            this.btnOptFour.TabIndex = 6;
            this.btnOptFour.Text = "button4";
            this.btnOptFour.UseVisualStyleBackColor = true;
            this.btnOptFour.Click += new System.EventHandler(this.btnOptFour_Click);
            // 
            // btnGone
            // 
            this.btnGone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGone.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnGone.Location = new System.Drawing.Point(713, 20);
            this.btnGone.Name = "btnGone";
            this.btnGone.Size = new System.Drawing.Size(75, 33);
            this.btnGone.TabIndex = 7;
            this.btnGone.Text = "Exit";
            this.btnGone.UseVisualStyleBackColor = true;
            this.btnGone.Click += new System.EventHandler(this.btnGone_Click);
            // 
            // btnValid
            // 
            this.btnValid.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnValid.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnValid.Location = new System.Drawing.Point(687, 393);
            this.btnValid.Name = "btnValid";
            this.btnValid.Size = new System.Drawing.Size(75, 33);
            this.btnValid.TabIndex = 8;
            this.btnValid.Text = "Check";
            this.btnValid.UseVisualStyleBackColor = true;
            this.btnValid.Click += new System.EventHandler(this.btnValid_Click);
            // 
            // lblLevelOne
            // 
            this.lblLevelOne.AutoSize = true;
            this.lblLevelOne.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblLevelOne.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblLevelOne.Location = new System.Drawing.Point(201, 426);
            this.lblLevelOne.Name = "lblLevelOne";
            this.lblLevelOne.Size = new System.Drawing.Size(113, 17);
            this.lblLevelOne.TabIndex = 27;
            this.lblLevelOne.Text = "Level One Master";
            this.lblLevelOne.Visible = false;
            // 
            // pbLvlOne
            // 
            this.pbLvlOne.Image = ((System.Drawing.Image)(resources.GetObject("pbLvlOne.Image")));
            this.pbLvlOne.Location = new System.Drawing.Point(223, 342);
            this.pbLvlOne.Name = "pbLvlOne";
            this.pbLvlOne.Size = new System.Drawing.Size(68, 72);
            this.pbLvlOne.TabIndex = 26;
            this.pbLvlOne.TabStop = false;
            this.pbLvlOne.Visible = false;
            // 
            // lbllevelTwo
            // 
            this.lbllevelTwo.AutoSize = true;
            this.lbllevelTwo.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbllevelTwo.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lbllevelTwo.Location = new System.Drawing.Point(350, 426);
            this.lbllevelTwo.Name = "lbllevelTwo";
            this.lbllevelTwo.Size = new System.Drawing.Size(111, 17);
            this.lbllevelTwo.TabIndex = 25;
            this.lbllevelTwo.Text = "Level Two Master";
            this.lbllevelTwo.Visible = false;
            // 
            // pbLvlTwo
            // 
            this.pbLvlTwo.Image = ((System.Drawing.Image)(resources.GetObject("pbLvlTwo.Image")));
            this.pbLvlTwo.Location = new System.Drawing.Point(367, 342);
            this.pbLvlTwo.Name = "pbLvlTwo";
            this.pbLvlTwo.Size = new System.Drawing.Size(68, 72);
            this.pbLvlTwo.TabIndex = 24;
            this.pbLvlTwo.TabStop = false;
            this.pbLvlTwo.Visible = false;
            // 
            // lblJack
            // 
            this.lblJack.AutoSize = true;
            this.lblJack.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblJack.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblJack.Location = new System.Drawing.Point(493, 426);
            this.lblJack.Name = "lblJack";
            this.lblJack.Size = new System.Drawing.Size(109, 17);
            this.lblJack.TabIndex = 29;
            this.lblJack.Text = "Jack of all trades";
            this.lblJack.Visible = false;
            // 
            // pbLvlThree
            // 
            this.pbLvlThree.Image = ((System.Drawing.Image)(resources.GetObject("pbLvlThree.Image")));
            this.pbLvlThree.Location = new System.Drawing.Point(510, 342);
            this.pbLvlThree.Name = "pbLvlThree";
            this.pbLvlThree.Size = new System.Drawing.Size(68, 72);
            this.pbLvlThree.TabIndex = 28;
            this.pbLvlThree.TabStop = false;
            this.pbLvlThree.Visible = false;
            // 
            // lblLevels
            // 
            this.lblLevels.AutoSize = true;
            this.lblLevels.Font = new System.Drawing.Font("Yu Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblLevels.Location = new System.Drawing.Point(43, 131);
            this.lblLevels.Name = "lblLevels";
            this.lblLevels.Size = new System.Drawing.Size(56, 25);
            this.lblLevels.TabIndex = 30;
            this.lblLevels.Text = "label";
            // 
            // FindingCN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblLevels);
            this.Controls.Add(this.lblJack);
            this.Controls.Add(this.pbLvlThree);
            this.Controls.Add(this.lblLevelOne);
            this.Controls.Add(this.pbLvlOne);
            this.Controls.Add(this.lbllevelTwo);
            this.Controls.Add(this.pbLvlTwo);
            this.Controls.Add(this.btnValid);
            this.Controls.Add(this.btnGone);
            this.Controls.Add(this.btnOptFour);
            this.Controls.Add(this.btnOptThree);
            this.Controls.Add(this.btnOptTwo);
            this.Controls.Add(this.btnOptOne);
            this.Controls.Add(this.lblCn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.Highlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FindingCN";
            this.Text = "FindingCN";
            this.Load += new System.EventHandler(this.FindingCN_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbLvlOne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLvlTwo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLvlThree)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCn;
        private System.Windows.Forms.Button btnOptOne;
        private System.Windows.Forms.Button btnOptTwo;
        private System.Windows.Forms.Button btnOptThree;
        private System.Windows.Forms.Button btnOptFour;
        private System.Windows.Forms.Button btnGone;
        private System.Windows.Forms.Button btnValid;
        private System.Windows.Forms.Label lblLevelOne;
        private System.Windows.Forms.PictureBox pbLvlOne;
        private System.Windows.Forms.Label lbllevelTwo;
        private System.Windows.Forms.PictureBox pbLvlTwo;
        private System.Windows.Forms.Label lblJack;
        private System.Windows.Forms.PictureBox pbLvlThree;
        private System.Windows.Forms.Label lblLevels;
    }
}