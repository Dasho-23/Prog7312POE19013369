﻿
namespace _190133369Task1
{
    partial class ReplacingBooks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReplacingBooks));
            this.btnItemOne = new System.Windows.Forms.Button();
            this.btnItemTwo = new System.Windows.Forms.Button();
            this.btnItemThree = new System.Windows.Forms.Button();
            this.btnItemFour = new System.Windows.Forms.Button();
            this.btnItemFive = new System.Windows.Forms.Button();
            this.btnItemSix = new System.Windows.Forms.Button();
            this.btnItemSeven = new System.Windows.Forms.Button();
            this.btnItemEight = new System.Windows.Forms.Button();
            this.btnItemNine = new System.Windows.Forms.Button();
            this.btnItemTen = new System.Windows.Forms.Button();
            this.btnCheck = new System.Windows.Forms.Button();
            this.rtbList = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.pbBadge = new System.Windows.Forms.PictureBox();
            this.lblBadge = new System.Windows.Forms.Label();
            this.btnTry = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbBadge)).BeginInit();
            this.SuspendLayout();
            // 
            // btnItemOne
            // 
            this.btnItemOne.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItemOne.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemOne.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnItemOne.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnItemOne.Location = new System.Drawing.Point(12, 12);
            this.btnItemOne.Name = "btnItemOne";
            this.btnItemOne.Size = new System.Drawing.Size(158, 26);
            this.btnItemOne.TabIndex = 0;
            this.btnItemOne.Text = "button1";
            this.btnItemOne.UseVisualStyleBackColor = false;
            this.btnItemOne.Click += new System.EventHandler(this.btnItemOne_Click);
            // 
            // btnItemTwo
            // 
            this.btnItemTwo.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItemTwo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemTwo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnItemTwo.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnItemTwo.Location = new System.Drawing.Point(12, 55);
            this.btnItemTwo.Name = "btnItemTwo";
            this.btnItemTwo.Size = new System.Drawing.Size(158, 26);
            this.btnItemTwo.TabIndex = 1;
            this.btnItemTwo.Text = "button2";
            this.btnItemTwo.UseVisualStyleBackColor = false;
            this.btnItemTwo.Click += new System.EventHandler(this.btnItemTwo_Click);
            // 
            // btnItemThree
            // 
            this.btnItemThree.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItemThree.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemThree.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnItemThree.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnItemThree.Location = new System.Drawing.Point(12, 101);
            this.btnItemThree.Name = "btnItemThree";
            this.btnItemThree.Size = new System.Drawing.Size(158, 28);
            this.btnItemThree.TabIndex = 2;
            this.btnItemThree.Text = "button3";
            this.btnItemThree.UseVisualStyleBackColor = false;
            this.btnItemThree.Click += new System.EventHandler(this.btnItemThree_Click);
            // 
            // btnItemFour
            // 
            this.btnItemFour.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItemFour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemFour.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnItemFour.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnItemFour.Location = new System.Drawing.Point(12, 147);
            this.btnItemFour.Name = "btnItemFour";
            this.btnItemFour.Size = new System.Drawing.Size(158, 26);
            this.btnItemFour.TabIndex = 3;
            this.btnItemFour.Text = "button4";
            this.btnItemFour.UseVisualStyleBackColor = false;
            this.btnItemFour.Click += new System.EventHandler(this.btnItemFour_Click);
            // 
            // btnItemFive
            // 
            this.btnItemFive.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItemFive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemFive.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnItemFive.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnItemFive.Location = new System.Drawing.Point(12, 191);
            this.btnItemFive.Name = "btnItemFive";
            this.btnItemFive.Size = new System.Drawing.Size(158, 30);
            this.btnItemFive.TabIndex = 4;
            this.btnItemFive.Text = "button5";
            this.btnItemFive.UseVisualStyleBackColor = false;
            this.btnItemFive.Click += new System.EventHandler(this.btnItemFive_Click);
            // 
            // btnItemSix
            // 
            this.btnItemSix.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItemSix.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemSix.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnItemSix.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnItemSix.Location = new System.Drawing.Point(12, 238);
            this.btnItemSix.Name = "btnItemSix";
            this.btnItemSix.Size = new System.Drawing.Size(158, 28);
            this.btnItemSix.TabIndex = 5;
            this.btnItemSix.Text = "button6";
            this.btnItemSix.UseVisualStyleBackColor = false;
            this.btnItemSix.Click += new System.EventHandler(this.btnItemSix_Click);
            // 
            // btnItemSeven
            // 
            this.btnItemSeven.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItemSeven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemSeven.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnItemSeven.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnItemSeven.Location = new System.Drawing.Point(12, 289);
            this.btnItemSeven.Name = "btnItemSeven";
            this.btnItemSeven.Size = new System.Drawing.Size(158, 28);
            this.btnItemSeven.TabIndex = 6;
            this.btnItemSeven.Text = "button7";
            this.btnItemSeven.UseVisualStyleBackColor = false;
            this.btnItemSeven.Click += new System.EventHandler(this.btnItemSeven_Click);
            // 
            // btnItemEight
            // 
            this.btnItemEight.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItemEight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemEight.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnItemEight.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnItemEight.Location = new System.Drawing.Point(12, 343);
            this.btnItemEight.Name = "btnItemEight";
            this.btnItemEight.Size = new System.Drawing.Size(158, 27);
            this.btnItemEight.TabIndex = 7;
            this.btnItemEight.Text = "button8";
            this.btnItemEight.UseVisualStyleBackColor = false;
            this.btnItemEight.Click += new System.EventHandler(this.btnItemEight_Click);
            // 
            // btnItemNine
            // 
            this.btnItemNine.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItemNine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemNine.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnItemNine.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnItemNine.Location = new System.Drawing.Point(12, 399);
            this.btnItemNine.Name = "btnItemNine";
            this.btnItemNine.Size = new System.Drawing.Size(158, 28);
            this.btnItemNine.TabIndex = 8;
            this.btnItemNine.Text = "button9";
            this.btnItemNine.UseVisualStyleBackColor = false;
            this.btnItemNine.Click += new System.EventHandler(this.btnItemNine_Click);
            // 
            // btnItemTen
            // 
            this.btnItemTen.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItemTen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnItemTen.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnItemTen.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnItemTen.Location = new System.Drawing.Point(12, 446);
            this.btnItemTen.Name = "btnItemTen";
            this.btnItemTen.Size = new System.Drawing.Size(158, 29);
            this.btnItemTen.TabIndex = 9;
            this.btnItemTen.Text = "button10";
            this.btnItemTen.UseVisualStyleBackColor = false;
            this.btnItemTen.Click += new System.EventHandler(this.btnItemTen_Click);
            // 
            // btnCheck
            // 
            this.btnCheck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCheck.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCheck.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnCheck.Location = new System.Drawing.Point(298, 414);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(75, 61);
            this.btnCheck.TabIndex = 10;
            this.btnCheck.Text = "Check";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // rtbList
            // 
            this.rtbList.Location = new System.Drawing.Point(196, 171);
            this.rtbList.Name = "rtbList";
            this.rtbList.Size = new System.Drawing.Size(592, 211);
            this.rtbList.TabIndex = 11;
            this.rtbList.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(278, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(422, 21);
            this.label1.TabIndex = 12;
            this.label1.Text = "Rearrange these calling numbers in ascending order. ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label2.Location = new System.Drawing.Point(298, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(321, 33);
            this.label2.TabIndex = 13;
            this.label2.Text = "Replacing call numbers";
            // 
            // btnExit
            // 
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnExit.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnExit.Location = new System.Drawing.Point(740, 7);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(48, 31);
            this.btnExit.TabIndex = 14;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pbBadge
            // 
            this.pbBadge.Image = ((System.Drawing.Image)(resources.GetObject("pbBadge.Image")));
            this.pbBadge.Location = new System.Drawing.Point(487, 407);
            this.pbBadge.Name = "pbBadge";
            this.pbBadge.Size = new System.Drawing.Size(68, 72);
            this.pbBadge.TabIndex = 15;
            this.pbBadge.TabStop = false;
            this.pbBadge.Visible = false;
            // 
            // lblBadge
            // 
            this.lblBadge.AutoSize = true;
            this.lblBadge.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblBadge.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblBadge.Location = new System.Drawing.Point(410, 482);
            this.lblBadge.Name = "lblBadge";
            this.lblBadge.Size = new System.Drawing.Size(271, 17);
            this.lblBadge.TabIndex = 16;
            this.lblBadge.Text = "Congrats! You win a Replacing books badge!";
            this.lblBadge.Visible = false;
            // 
            // btnTry
            // 
            this.btnTry.Enabled = false;
            this.btnTry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTry.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTry.ForeColor = System.Drawing.SystemColors.Highlight;
            this.btnTry.Location = new System.Drawing.Point(693, 414);
            this.btnTry.Name = "btnTry";
            this.btnTry.Size = new System.Drawing.Size(75, 65);
            this.btnTry.TabIndex = 17;
            this.btnTry.Text = "Try again";
            this.btnTry.UseVisualStyleBackColor = true;
            this.btnTry.Visible = false;
            this.btnTry.Click += new System.EventHandler(this.btnTry_Click);
            // 
            // ReplacingBooks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(800, 508);
            this.Controls.Add(this.btnTry);
            this.Controls.Add(this.lblBadge);
            this.Controls.Add(this.pbBadge);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rtbList);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.btnItemTen);
            this.Controls.Add(this.btnItemNine);
            this.Controls.Add(this.btnItemEight);
            this.Controls.Add(this.btnItemSeven);
            this.Controls.Add(this.btnItemSix);
            this.Controls.Add(this.btnItemFive);
            this.Controls.Add(this.btnItemFour);
            this.Controls.Add(this.btnItemThree);
            this.Controls.Add(this.btnItemTwo);
            this.Controls.Add(this.btnItemOne);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ReplacingBooks";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReplacingBooks";
            this.Load += new System.EventHandler(this.ReplacingBooks_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbBadge)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnItemOne;
        private System.Windows.Forms.Button btnItemTwo;
        private System.Windows.Forms.Button btnItemThree;
        private System.Windows.Forms.Button btnItemFour;
        private System.Windows.Forms.Button btnItemFive;
        private System.Windows.Forms.Button btnItemSix;
        private System.Windows.Forms.Button btnItemSeven;
        private System.Windows.Forms.Button btnItemEight;
        private System.Windows.Forms.Button btnItemNine;
        private System.Windows.Forms.Button btnItemTen;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.RichTextBox rtbList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.PictureBox pbBadge;
        private System.Windows.Forms.Label lblBadge;
        private System.Windows.Forms.Button btnTry;
    }
}