﻿
namespace _190133369Task1
{
    partial class IdentifyingAreas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IdentifyingAreas));
            this.btnEnd = new System.Windows.Forms.Button();
            this.btnChe = new System.Windows.Forms.Button();
            this.btnTA = new System.Windows.Forms.Button();
            this.lblFirColOne = new System.Windows.Forms.Label();
            this.lblFirColFour = new System.Windows.Forms.Label();
            this.lblFirColThree = new System.Windows.Forms.Label();
            this.lblFirColTwo = new System.Windows.Forms.Label();
            this.btnSecColOne = new System.Windows.Forms.Button();
            this.btnSecColTwo = new System.Windows.Forms.Button();
            this.btnSecColThree = new System.Windows.Forms.Button();
            this.btnSecColFour = new System.Windows.Forms.Button();
            this.btnSecColFive = new System.Windows.Forms.Button();
            this.btnSecColSix = new System.Windows.Forms.Button();
            this.btnSecColSeven = new System.Windows.Forms.Button();
            this.rtbAnswer = new System.Windows.Forms.RichTextBox();
            this.lblBadgeT = new System.Windows.Forms.Label();
            this.pbBadgeT = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblinstruction = new System.Windows.Forms.Label();
            this.lblLoser = new System.Windows.Forms.Label();
            this.pbLoser = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbBadgeT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLoser)).BeginInit();
            this.SuspendLayout();
            // 
            // btnEnd
            // 
            this.btnEnd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEnd.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnEnd.Location = new System.Drawing.Point(695, 11);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(50, 31);
            this.btnEnd.TabIndex = 0;
            this.btnEnd.Text = "Exit";
            this.btnEnd.UseVisualStyleBackColor = true;
            this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // btnChe
            // 
            this.btnChe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChe.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnChe.Location = new System.Drawing.Point(677, 390);
            this.btnChe.Name = "btnChe";
            this.btnChe.Size = new System.Drawing.Size(68, 31);
            this.btnChe.TabIndex = 1;
            this.btnChe.Text = "Check ";
            this.btnChe.UseVisualStyleBackColor = true;
            this.btnChe.Click += new System.EventHandler(this.btnChe_Click);
            // 
            // btnTA
            // 
            this.btnTA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTA.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnTA.Location = new System.Drawing.Point(650, 432);
            this.btnTA.Name = "btnTA";
            this.btnTA.Size = new System.Drawing.Size(95, 31);
            this.btnTA.TabIndex = 2;
            this.btnTA.Text = "Try Again";
            this.btnTA.UseVisualStyleBackColor = true;
            this.btnTA.Click += new System.EventHandler(this.btnTA_Click);
            // 
            // lblFirColOne
            // 
            this.lblFirColOne.AutoSize = true;
            this.lblFirColOne.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblFirColOne.Location = new System.Drawing.Point(163, 150);
            this.lblFirColOne.Name = "lblFirColOne";
            this.lblFirColOne.Size = new System.Drawing.Size(56, 20);
            this.lblFirColOne.TabIndex = 3;
            this.lblFirColOne.Text = "label1";
            // 
            // lblFirColFour
            // 
            this.lblFirColFour.AutoSize = true;
            this.lblFirColFour.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblFirColFour.Location = new System.Drawing.Point(163, 299);
            this.lblFirColFour.Name = "lblFirColFour";
            this.lblFirColFour.Size = new System.Drawing.Size(56, 20);
            this.lblFirColFour.TabIndex = 4;
            this.lblFirColFour.Text = "label2";
            // 
            // lblFirColThree
            // 
            this.lblFirColThree.AutoSize = true;
            this.lblFirColThree.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblFirColThree.Location = new System.Drawing.Point(163, 247);
            this.lblFirColThree.Name = "lblFirColThree";
            this.lblFirColThree.Size = new System.Drawing.Size(56, 20);
            this.lblFirColThree.TabIndex = 5;
            this.lblFirColThree.Text = "label3";
            // 
            // lblFirColTwo
            // 
            this.lblFirColTwo.AutoSize = true;
            this.lblFirColTwo.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblFirColTwo.Location = new System.Drawing.Point(163, 198);
            this.lblFirColTwo.Name = "lblFirColTwo";
            this.lblFirColTwo.Size = new System.Drawing.Size(56, 20);
            this.lblFirColTwo.TabIndex = 6;
            this.lblFirColTwo.Text = "label4";
            // 
            // btnSecColOne
            // 
            this.btnSecColOne.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSecColOne.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSecColOne.Location = new System.Drawing.Point(352, 113);
            this.btnSecColOne.Name = "btnSecColOne";
            this.btnSecColOne.Size = new System.Drawing.Size(247, 31);
            this.btnSecColOne.TabIndex = 7;
            this.btnSecColOne.Text = "Check ";
            this.btnSecColOne.UseVisualStyleBackColor = true;
            this.btnSecColOne.Click += new System.EventHandler(this.btnSecColOne_Click);
            // 
            // btnSecColTwo
            // 
            this.btnSecColTwo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSecColTwo.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSecColTwo.Location = new System.Drawing.Point(352, 150);
            this.btnSecColTwo.Name = "btnSecColTwo";
            this.btnSecColTwo.Size = new System.Drawing.Size(247, 31);
            this.btnSecColTwo.TabIndex = 8;
            this.btnSecColTwo.Text = "Check ";
            this.btnSecColTwo.UseVisualStyleBackColor = true;
            this.btnSecColTwo.Click += new System.EventHandler(this.btnSecColTwo_Click);
            // 
            // btnSecColThree
            // 
            this.btnSecColThree.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSecColThree.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSecColThree.Location = new System.Drawing.Point(352, 187);
            this.btnSecColThree.Name = "btnSecColThree";
            this.btnSecColThree.Size = new System.Drawing.Size(247, 31);
            this.btnSecColThree.TabIndex = 9;
            this.btnSecColThree.Text = "Check ";
            this.btnSecColThree.UseVisualStyleBackColor = true;
            this.btnSecColThree.Click += new System.EventHandler(this.btnSecColThree_Click);
            // 
            // btnSecColFour
            // 
            this.btnSecColFour.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSecColFour.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSecColFour.Location = new System.Drawing.Point(352, 224);
            this.btnSecColFour.Name = "btnSecColFour";
            this.btnSecColFour.Size = new System.Drawing.Size(247, 31);
            this.btnSecColFour.TabIndex = 10;
            this.btnSecColFour.Text = "Check ";
            this.btnSecColFour.UseVisualStyleBackColor = true;
            this.btnSecColFour.Click += new System.EventHandler(this.btnSecColFour_Click);
            // 
            // btnSecColFive
            // 
            this.btnSecColFive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSecColFive.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSecColFive.Location = new System.Drawing.Point(352, 261);
            this.btnSecColFive.Name = "btnSecColFive";
            this.btnSecColFive.Size = new System.Drawing.Size(247, 31);
            this.btnSecColFive.TabIndex = 11;
            this.btnSecColFive.Text = "Check ";
            this.btnSecColFive.UseVisualStyleBackColor = true;
            this.btnSecColFive.Click += new System.EventHandler(this.btnSecColFive_Click);
            // 
            // btnSecColSix
            // 
            this.btnSecColSix.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSecColSix.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSecColSix.Location = new System.Drawing.Point(352, 302);
            this.btnSecColSix.Name = "btnSecColSix";
            this.btnSecColSix.Size = new System.Drawing.Size(247, 31);
            this.btnSecColSix.TabIndex = 12;
            this.btnSecColSix.Text = "Check ";
            this.btnSecColSix.UseVisualStyleBackColor = true;
            this.btnSecColSix.Click += new System.EventHandler(this.btnSecColSix_Click);
            // 
            // btnSecColSeven
            // 
            this.btnSecColSeven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSecColSeven.Font = new System.Drawing.Font("Segoe UI Emoji", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSecColSeven.Location = new System.Drawing.Point(352, 348);
            this.btnSecColSeven.Name = "btnSecColSeven";
            this.btnSecColSeven.Size = new System.Drawing.Size(247, 31);
            this.btnSecColSeven.TabIndex = 13;
            this.btnSecColSeven.Text = "Check ";
            this.btnSecColSeven.UseVisualStyleBackColor = true;
            this.btnSecColSeven.Click += new System.EventHandler(this.btnSecColSeven_Click);
            // 
            // rtbAnswer
            // 
            this.rtbAnswer.Location = new System.Drawing.Point(72, 411);
            this.rtbAnswer.Name = "rtbAnswer";
            this.rtbAnswer.Size = new System.Drawing.Size(318, 52);
            this.rtbAnswer.TabIndex = 14;
            this.rtbAnswer.Text = "";
            // 
            // lblBadgeT
            // 
            this.lblBadgeT.AutoSize = true;
            this.lblBadgeT.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblBadgeT.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblBadgeT.Location = new System.Drawing.Point(396, 495);
            this.lblBadgeT.Name = "lblBadgeT";
            this.lblBadgeT.Size = new System.Drawing.Size(271, 17);
            this.lblBadgeT.TabIndex = 18;
            this.lblBadgeT.Text = "Congrats! You win a Identifying areas badge!";
            this.lblBadgeT.Visible = false;
            // 
            // pbBadgeT
            // 
            this.pbBadgeT.Image = ((System.Drawing.Image)(resources.GetObject("pbBadgeT.Image")));
            this.pbBadgeT.Location = new System.Drawing.Point(495, 411);
            this.pbBadgeT.Name = "pbBadgeT";
            this.pbBadgeT.Size = new System.Drawing.Size(68, 72);
            this.pbBadgeT.TabIndex = 17;
            this.pbBadgeT.TabStop = false;
            this.pbBadgeT.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label2.Location = new System.Drawing.Point(263, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(233, 33);
            this.label2.TabIndex = 20;
            this.label2.Text = "Identifying Areas";
            // 
            // lblinstruction
            // 
            this.lblinstruction.AutoSize = true;
            this.lblinstruction.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblinstruction.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblinstruction.Location = new System.Drawing.Point(175, 68);
            this.lblinstruction.Name = "lblinstruction";
            this.lblinstruction.Size = new System.Drawing.Size(403, 21);
            this.lblinstruction.TabIndex = 19;
            this.lblinstruction.Text = "Match the call numbers to the correct description.";
            // 
            // lblLoser
            // 
            this.lblLoser.AutoSize = true;
            this.lblLoser.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblLoser.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblLoser.Location = new System.Drawing.Point(396, 495);
            this.lblLoser.Name = "lblLoser";
            this.lblLoser.Size = new System.Drawing.Size(263, 17);
            this.lblLoser.TabIndex = 23;
            this.lblLoser.Text = "Congrats! You win the Biggest Loser badge!";
            this.lblLoser.Visible = false;
            // 
            // pbLoser
            // 
            this.pbLoser.Image = ((System.Drawing.Image)(resources.GetObject("pbLoser.Image")));
            this.pbLoser.Location = new System.Drawing.Point(495, 411);
            this.pbLoser.Name = "pbLoser";
            this.pbLoser.Size = new System.Drawing.Size(68, 72);
            this.pbLoser.TabIndex = 22;
            this.pbLoser.TabStop = false;
            this.pbLoser.Visible = false;
            // 
            // IdentifyingAreas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(757, 520);
            this.Controls.Add(this.lblLoser);
            this.Controls.Add(this.pbLoser);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblinstruction);
            this.Controls.Add(this.lblBadgeT);
            this.Controls.Add(this.pbBadgeT);
            this.Controls.Add(this.rtbAnswer);
            this.Controls.Add(this.btnSecColSeven);
            this.Controls.Add(this.btnSecColSix);
            this.Controls.Add(this.btnSecColFive);
            this.Controls.Add(this.btnSecColFour);
            this.Controls.Add(this.btnSecColThree);
            this.Controls.Add(this.btnSecColTwo);
            this.Controls.Add(this.btnSecColOne);
            this.Controls.Add(this.lblFirColTwo);
            this.Controls.Add(this.lblFirColThree);
            this.Controls.Add(this.lblFirColFour);
            this.Controls.Add(this.lblFirColOne);
            this.Controls.Add(this.btnTA);
            this.Controls.Add(this.btnChe);
            this.Controls.Add(this.btnEnd);
            this.ForeColor = System.Drawing.SystemColors.Highlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "IdentifyingAreas";
            this.Text = "IdentifyingAreas";
            this.Load += new System.EventHandler(this.IdentifyingAreas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbBadgeT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLoser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.Button btnChe;
        private System.Windows.Forms.Button btnTA;
        private System.Windows.Forms.Label lblFirColOne;
        private System.Windows.Forms.Label lblFirColFour;
        private System.Windows.Forms.Label lblFirColThree;
        private System.Windows.Forms.Label lblFirColTwo;
        private System.Windows.Forms.Button btnSecColOne;
        private System.Windows.Forms.Button btnSecColTwo;
        private System.Windows.Forms.Button btnSecColThree;
        private System.Windows.Forms.Button btnSecColFour;
        private System.Windows.Forms.Button btnSecColFive;
        private System.Windows.Forms.Button btnSecColSix;
        private System.Windows.Forms.Button btnSecColSeven;
        private System.Windows.Forms.RichTextBox rtbAnswer;
        private System.Windows.Forms.Label lblBadgeT;
        private System.Windows.Forms.PictureBox pbBadgeT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblinstruction;
        private System.Windows.Forms.Label lblLoser;
        private System.Windows.Forms.PictureBox pbLoser;
    }
}