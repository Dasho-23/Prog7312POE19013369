﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _19013369Task1
{
    public partial class FindingCN : Form
    {
        //creates an object of the CallNumberTf class
        CallNumberTF tf = new CallNumberTF();
        
        //declaring fields 
        string answer = "", userAnswer = " ", Levels=" ";
        public FindingCN()
        {
            InitializeComponent();
        }

        private void FindingCN_Load(object sender, EventArgs e)
        {
            //loads the data from the textfile
            tf.ReadTextFiLe();

            //calls on level one method
            LevelOne();
            
            //hides badges if visible
            pbLvlOne.Visible = false;
            lblLevelOne.Visible = false;
            pbLvlTwo.Visible = false;
            lbllevelTwo.Visible = false;
            pbLvlThree.Visible = false;
            lblJack.Visible = false;
        }
        //method that loads level one 
        public void LevelOne()
        {
            //lets the user know what level they are on
            Levels = "One";
            lblLevels.Text = "Level: " + Levels;

            answer = " ";

            //generates a random number between 0 and 9
            Random rand = new Random();
            int number = rand.Next(0, 10);

            //declares an array 
            String[] datalist;

            //splits the string in the list in to call number and description 
            datalist = tf.lvlOne[number].Split("*");

            //call number is shown to the user
            lblCn.Text = datalist[1].ToString();

            //the correct description is stored here 
            answer = datalist[0].ToString();

            //button is popluated with description
            btnOptFour.Text = answer;

            //generates a random number between 0 and 9
            int i = rand.Next(0, 10);

            //declares an array 
            String[] datalistTwo;

            //splits the string in the list in to call number and description 

            datalistTwo = tf.lvlOne[i].Split("*");

            //button is popluated with description
            btnOptThree.Text = datalistTwo[0].ToString();

            //generates a random number between 0 and 9
            int y = rand.Next(0, 10);

            //declares an array 
            String[] datalistThree;

            //splits the string in the list in to call number and description 
            datalistThree = tf.lvlOne[y].Split("*");

            //button is popluated with description
            btnOptTwo.Text = datalistThree[0].ToString();

            //generates a random number between 0 and 9
            int r = rand.Next(0, 10);

            //declares an array 
            String[] datalistFour;

            //splits the string in the list in to call number and description 
            datalistFour = tf.lvlOne[r].Split("*");

            //button is popluated with description
            btnOptOne.Text = datalistFour[0].ToString();

        }
        public void LevelTwo()
        {
            //lets the user know what level they are on
            Levels = "Two";
            lblLevels.Text = "Level: " + Levels;

            answer = " ";

            //generates a random number between 0 and 9
            Random rand = new Random();
            int number = rand.Next(0, 10);

            //declares an array 
            String[] datalist;

            //splits the string in the list in to call number and description 
            datalist = tf.lvlTwo[number].Split("!");

            //call number is shown to the user
            lblCn.Text = datalist[1].ToString();

            //the correct description is stored here 
            answer = datalist[0].ToString();

            //button is popluated with description
            btnOptTwo.Text = answer;

            //generates a random number between 0 and 9
            int i = rand.Next(0, 10);

            //declares an array 
            String[] datalistTwo;

            //splits the string in the list in to call number and description 
            datalistTwo = tf.lvlTwo[i].Split("!");

            //button is popluated with description
            btnOptFour.Text = datalistTwo[0].ToString();

            //generates a random number between 0 and 9
            int y = rand.Next(0, 10);

            //declares an array 
            String[] datalistThree;

            //splits the string in the list in to call number and description 
            datalistThree = tf.lvlTwo[y].Split("!");

            //button is popluated with description
            btnOptThree.Text = datalistThree[0].ToString();

            //generates a random number between 0 and 9
            int r = rand.Next(0, 10);

            //declares an array 
            String[] datalistFour;

            //splits the string in the list in to call number and description 
            datalistFour = tf.lvlTwo[r].Split("!");

            //button is popluated with description
            btnOptOne.Text = datalistFour[0].ToString();

        }
        public void LevelThree()
        {
            //lets the user know what level they are on
            Levels = "Three";
            lblLevels.Text = "Level: " + Levels;

            answer = " ";

            //generates a random number between 0 and 90
            Random rand = new Random();
            int number = rand.Next(0, 91);

            //declares an array
            String[] datalist;

            //splits the string in the list in to call number and description 
            datalist = tf.lvlThree[number].Split("@");

            //call number is shown to the user
            lblCn.Text = datalist[1].ToString();


            //the correct description is stored here 
            answer = datalist[0].ToString();

            //button is popluated with description
            btnOptOne.Text = answer;

            //generates a random number between 0 and 90
            int i = rand.Next(0, 91);

            //declares an array
            String[] datalistTwo;

            //splits the string in the list in to call number and description 
            datalistTwo = tf.lvlThree[i].Split("@");

            //button is popluated with description
            btnOptFour.Text = datalistTwo[0].ToString();

            //generates a random number between 0 and 90
            int o = rand.Next(0, 91);

            //declares an array
            String[] datalistThree;

            //splits the string in the list in to call number and description 
            datalistThree = tf.lvlThree[o].Split("@");

            //button is popluated with description
            btnOptThree.Text = datalistThree[0].ToString();

            //generates a random number between 0 and 90
            int r = rand.Next(0, 91);

            //declares an array
            String[] datalistFour;

            //splits the string in the list in to call number and description 
            datalistFour = tf.lvlThree[r].Split("@");

            //button is popluated with description
            btnOptTwo.Text = datalistFour[0].ToString();

        }

        private void btnGone_Click(object sender, EventArgs e)
        {
            //stops the execution of the program
            this.Close();
        }

        private void btnOptTwo_Click(object sender, EventArgs e)
        {
            //stores the user's answer in the variable
            userAnswer = btnOptTwo.Text;
        }

        private void btnOptThree_Click(object sender, EventArgs e)
        {
            //stores the user's answer in the variable
            userAnswer = btnOptThree.Text;
        }

        private void btnOptFour_Click(object sender, EventArgs e)
        {
            //stores the user's answer in the variable
            userAnswer = btnOptFour.Text;
        }

      
      

        private void btnValid_Click(object sender, EventArgs e)
        {
            //checks if the user's answer is correct
            //if the user answers are correct then the user moves to level two
            if (answer.Equals(userAnswer) && Levels.Equals("One"))
            {
                //Gamefication feature
                //displays badges
                pbLvlOne.Visible = true;
                lblLevelOne.Visible = true;
            
                //Loads level Two
                LevelTwo();
            }
            //if the user answers are correct then the user moves to level Three
            else if ( answer.Equals(userAnswer) && Levels.Equals("Two"))
            {
                //Gamefication feature
                //displays badges
                pbLvlTwo.Visible = true;
                lbllevelTwo.Visible = true;

               //Loads level three question
                LevelThree();
            }
            //if the user answers are correct, they win a badge
            else if (answer.Equals(userAnswer) && Levels.Equals("Three"))
            {
                //Gamefication feature
                //displays badges
                pbLvlThree.Visible = true;
                lblJack.Visible = true;
            
            }else // if the answer is wrong the user's badges aretaken away and start at Level one again
            {
                //Gamefication feature
                //takes away user's badge 
                pbLvlOne.Visible = false;
                lblLevelOne.Visible = false;
                pbLvlTwo.Visible = false;
                lbllevelTwo.Visible = false;
                pbLvlThree.Visible = false;
                lblJack.Visible = false;

                //lets the user know they have lost thier badges
                MessageBox.Show("No badges for you");

                //loads level one questions
                LevelOne();
            }
        }

        private void btnOptOne_Click(object sender, EventArgs e)
        {
            userAnswer = btnOptOne.Text;

        }
    }
}
