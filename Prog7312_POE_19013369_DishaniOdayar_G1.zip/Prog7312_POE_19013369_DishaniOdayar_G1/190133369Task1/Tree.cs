﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _19013369Task1
{
    class Tree
    {
    }
}
